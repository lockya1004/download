package com.example.hyun.contactlist;

import java.io.Serializable;

/**
 * Created by hyun on 2018-03-31.
 */

public class PhoneItem implements Serializable{

    private String name;
    private String mobile;

    public PhoneItem() {
    }

    public PhoneItem(String name, String mobile) {
        this.name = name;
        this.mobile = mobile;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }
}
