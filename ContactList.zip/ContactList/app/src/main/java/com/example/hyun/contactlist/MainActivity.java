package com.example.hyun.contactlist;



import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;


import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    RecyclerView rv;
    ImageButton ib_add;
    SQLiteDatabase db;
    List<PhoneItem> list=new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ib_add = findViewById(R.id.ib_add);
        allstart();


        ib_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MemeberADD.class);
                startActivity(intent);
            }
        });
    }

    public void allstart() {
        init();
        openDB();
        createTable();
        insertData();
        initData();
    }


    public void openDB() {
        db = openOrCreateDatabase("contact", MODE_PRIVATE, null);
        if (db != null) {
            Log.i("DB", "오픈");
        } else {
            Log.i("DB", "생성");
        }
    }

    public void createTable() {
        if (db != null) {
            String sql = "create table  contact (_id integer PRIMARY KEY autoincrement, name text, mobile text)";
            try {
                db.execSQL(sql);
                Log.i("Table", "createTable() 생성됨");
            } catch (Exception e) {
                Log.i("Table", "이미 생성되어 있는 테이블");
            }
        } else {
            Log.i("Table", "먼저 DB를 오픈하세요");
        }
    }

    public void insertData() {
        Intent intent = getIntent();
        PhoneItem item = (PhoneItem) intent.getSerializableExtra("phoneItem");
        if (item != null) {
            String name = item.getName();
            String mobile = item.getMobile();
            if (db != null) {
                String sql = "insert into contact(name,mobile) values(?,?)";
                Object[] params = new Object[2];
                params[0] = name;
                params[1] = mobile;

                db.execSQL(sql, params);
                Log.i("Data", "데이터 추가");
            } else {
                Log.i("Table", "먼저 DB를 오픈하세요");
            }
        }
    }

    public void init() {
        rv = findViewById(R.id.rv);

    }

    public void initData() {
        if (db != null) {
            String sql = "select name, mobile from contact";
            Cursor cursor = db.rawQuery(sql, null);
            while (cursor.moveToNext()) {
                PhoneItem item = new PhoneItem();
                item.setName(cursor.getString(0));
                item.setMobile(cursor.getString(1));
                list.add(item);
            }

            rv.setAdapter(new PhoneAdapter(list,R.layout.activity_phone));
            rv.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
            rv.setItemAnimator(new DefaultItemAnimator());



        }

    }

}
