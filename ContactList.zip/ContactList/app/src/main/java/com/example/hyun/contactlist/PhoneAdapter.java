package com.example.hyun.contactlist;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.List;

/**
 * Created by hyun on 2018-04-01.
 */

public class PhoneAdapter extends RecyclerView.Adapter<PhoneAdapter.ViewHolder>{
    List<PhoneItem> list;
    int itemLayout;

    public PhoneAdapter(List<PhoneItem> list, int itemLayout) {
        this.list = list;
        this.itemLayout = itemLayout;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(itemLayout,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        PhoneItem item = list.get(position);
        holder.tv_name.setText(item.getName());
        holder.tv_mobile.setText(item.getMobile());
        holder.ib_call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Context c=view.getContext();
                Uri num=Uri.parse("tel:"+list.get(position).getMobile());
                Intent intent=new Intent(Intent.ACTION_CALL);
                        intent.setData(num);
                    c.startActivity(intent);

                 }
        });

        holder.itemView.setTag(item);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView tv_name,tv_mobile;
        ImageButton ib_call;

        public ViewHolder(View itemView) {
            super(itemView);
            ib_call= itemView.findViewById(R.id.ib_call);
            tv_name=itemView.findViewById(R.id.tv_name);
            tv_mobile=itemView.findViewById(R.id.tv_mobile);

        }
    }

}
